Indo :
• Salin/potong folder codexplore.ojol
• Buka Folder Android > Data > Tempel

English:
• Copy/cut folder codexplore.ojol
• Open folder Android > Data > Paste